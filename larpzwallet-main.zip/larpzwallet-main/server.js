// server.js - ES Modules Version
import express from 'express';
import cookieParser from 'cookie-parser';
import jwt from 'jsonwebtoken';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import path from 'path';
import crypto from 'crypto';
import { createRequire } from 'module';
import fs from 'fs';
import { fileURLToPath } from 'url';

const require = createRequire(import.meta.url);
require('dotenv').config();

const app = express();

// --- ES Modules equivalents for __dirname and __filename ---
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// --- Ordner & DB Setup ---
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_FILE = path.join(DATA_DIR, 'larp.db');

// --- CORS ---
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Admin-Secret');
  res.header('Access-Control-Allow-Credentials', 'true');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

app.use(express.json());
app.use(cookieParser());

// --- Secrets ---
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(64).toString('hex');

if (!process.env.ADMIN_PASSWORD) {
  console.error('ERROR: ADMIN_PASSWORD not set! Please create a .env file with ADMIN_PASSWORD=your-password');
  process.exit(1);
}
const ADMIN_SECRET_HASH = crypto.createHash('sha256').update(process.env.ADMIN_PASSWORD).digest('hex');

// --- Rate Limiting ---
const rateLimitMap = new Map();
const MAX_ATTEMPTS = 5;
const LOCKOUT_TIME = 15 * 60 * 1000;

function rateLimit(req, res, next) {
  const ip = req.ip || req.connection.remoteAddress;
  const now = Date.now();
  if (!rateLimitMap.has(ip)) rateLimitMap.set(ip, { attempts: 0, lockedUntil: 0 });
  const record = rateLimitMap.get(ip);
  if (record.lockedUntil > now) {
    const remaining = Math.ceil((record.lockedUntil - now) / 1000);
    return res.status(429).json({ error: `Too many attempts. Try again in ${remaining} seconds.` });
  }
  req.rateLimit = record;
  next();
}

// --- SQLite DB ---
const dbPromise = open({ filename: DB_FILE, driver: sqlite3.Database });

(async () => {
  const db = await dbPromise;
  await db.exec(`
    CREATE TABLE IF NOT EXISTS licenses (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      license_key TEXT UNIQUE NOT NULL,
      plan TEXT NOT NULL,
      duration_days INTEGER,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      activated_at TEXT,
      expires_at TEXT,
      device_id TEXT,
      is_active INTEGER DEFAULT 1
    );
  `);
})();

// --- Admin Auth ---
function adminAuth(req, res, next) {
  const record = req.rateLimit;
  const now = Date.now();
  if (record.lockedUntil > 0 && record.lockedUntil < now) { record.attempts = 0; record.lockedUntil = 0; }
  const secret = req.headers['x-admin-secret'];
  if (!secret) return res.status(401).json({ error: 'Unauthorized' });
  const hash = crypto.createHash('sha256').update(secret).digest('hex');
  if (hash !== ADMIN_SECRET_HASH) {
    record.attempts++;
    if (record.attempts >= MAX_ATTEMPTS) { record.lockedUntil = now + LOCKOUT_TIME; return res.status(429).json({ error: 'Too many failed attempts. Account locked for 15 minutes.' }); }
    const remaining = MAX_ATTEMPTS - record.attempts;
    return res.status(401).json({ error: `Invalid password. ${remaining} attempts remaining.` });
  }
  record.attempts = 0;
  next();
}

// --- License Activation ---
app.get('/api/license/validate', licenseAuth, (req, res) => res.json({ valid: true }));

app.post('/api/license/activate', async (req, res) => {
  const { key, deviceId } = req.body || {};
  if (!key || !deviceId) return res.status(400).json({ error: 'Missing key or deviceId' });

  const db = await dbPromise;
  const license = await db.get('SELECT * FROM licenses WHERE license_key = ?', key);
  if (!license) return res.status(404).json({ error: 'License not found' });

  const now = new Date();
  if (license.expires_at && new Date(license.expires_at) < now) return res.status(400).json({ error: 'License expired' });
  if (!license.is_active && license.activated_at) return res.status(403).json({ error: 'License has been disabled by admin' });
  if (license.device_id && license.device_id !== deviceId) return res.status(403).json({ error: 'License already bound to another device' });

  let expiresAt = license.expires_at;
  if (!license.activated_at) {
    if (license.duration_days != null) expiresAt = new Date(Date.now() + license.duration_days*24*60*60*1000).toISOString();
    await db.run('UPDATE licenses SET device_id = ?, activated_at = ?, expires_at = ?, is_active = 1 WHERE id = ?',
      deviceId, now.toISOString(), expiresAt, license.id
    );
  }

  const token = jwt.sign({ licenseId: license.id, deviceId }, JWT_SECRET, { expiresIn: '60d' });
  const isProd = process.env.NODE_ENV === 'production';

  res.cookie('auth_token', token, { httpOnly: true, secure: isProd, sameSite: 'lax', maxAge: 60*24*60*60*1000 });
  res.cookie('device_id', deviceId, { httpOnly: false, secure: isProd, sameSite: 'lax', maxAge: 60*24*60*60*1000 });
  res.json({ success: true });
});

// --- License Auth Middleware ---
async function licenseAuth(req, res, next) {
  const token = req.cookies.auth_token;
  const deviceId = req.cookies.device_id || req.query.deviceId;
  if (!token) return res.redirect('/dashboard.html');

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    if (payload.deviceId !== deviceId) return res.redirect('/dashboard.html');

    const db = await dbPromise;
    const license = await db.get('SELECT * FROM licenses WHERE id = ?', payload.licenseId);
    if (!license || !license.is_active) return res.redirect('/dashboard.html');
    if (license.expires_at && new Date(license.expires_at) < new Date()) return res.redirect('/dashboard.html');
    if (license.device_id !== payload.deviceId) return res.redirect('/dashboard.html');

    req.license = license;
    next();
  } catch {
    return res.redirect('/dashboard.html');
  }
}

// --- Protected Pages ---
app.get('/welcome.html', licenseAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'welcome.html'));
});
app.get('/app', licenseAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'larp.html'));
});

// --- Block direct access to protected HTML ---
app.use((req, res, next) => {
  if (['/welcome.html', '/larp.html', '/larp'].includes(req.path)) return res.redirect('/dashboard.html');
  next();
});

// --- Public static files ---
app.use(express.static(__dirname, {
  extensions: ['html','css','js','json','svg','ico','webmanifest'],
  index: false,
  setHeaders: (res, filePath) => {
    const forbidden = ['server.js','.env','.env.example','larp.db','package-lock.json'];
    if (forbidden.includes(path.basename(filePath))) res.status(403).end('Forbidden');
  }
}));

// --- Admin Routes (simplified) ---
app.get('/api/admin/licenses', rateLimit, adminAuth, async (req, res) => {
  try {
    const db = await dbPromise;
    const licenses = await db.all('SELECT * FROM licenses ORDER BY created_at DESC');
    res.json(licenses);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Failed to fetch licenses' });
  }
});

app.post('/api/admin/create-license', rateLimit, adminAuth, async (req, res) => {
  const { plan, customKey, customExpiry, quantity } = req.body;
  if (!['starter','pro','advanced'].includes(plan)) return res.status(400).json({ error: 'Invalid plan' });

  const qty = Math.min(Math.max(parseInt(quantity)||1,1),100);
  const db = await dbPromise;
  const keys = [];
  const createdAt = new Date().toISOString();

  for (let i=0;i<qty;i++){
    let key = customKey ? customKey.trim().toUpperCase() : `LARP-${Math.random().toString(36).substr(2,4).toUpperCase()}-${Math.random().toString(36).substr(2,4).toUpperCase()}-${Math.random().toString(36).substr(2,4).toUpperCase()}`;
    if (customKey && qty>1) key += `-${(i+1).toString().padStart(3,'0')}`;
    const exists = await db.get('SELECT id FROM licenses WHERE license_key = ?', key);
    if (exists) key += `-${Date.now()}`;
    let duration = plan==='starter'?7:plan==='pro'?30:null;
    if (customExpiry) duration = customExpiry;
    const expiresAt = duration ? new Date(Date.now()+duration*24*60*60*1000).toISOString() : null;
    await db.run('INSERT INTO licenses (license_key,plan,duration_days,created_at,expires_at,is_active) VALUES (?,?,?,?,?,0)', key, plan, duration, createdAt, expiresAt);
    keys.push(key);
  }
  res.json({ keys, plan, quantity: qty });
});

// --- Delete license ---
app.delete('/api/admin/license/:key', rateLimit, adminAuth, async (req, res) => {
  try {
    const { key } = req.params;
    const db = await dbPromise;
    const result = await db.run('DELETE FROM licenses WHERE license_key = ?', key);
    if (result.changes === 0) return res.status(404).json({ error: 'License not found' });
    res.json({ success: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Failed to delete' });
  }
});

// --- Toggle license status ---
app.post('/api/admin/license/:key/toggle', rateLimit, adminAuth, async (req, res) => {
  try {
    const { key } = req.params;
    const { isActive } = req.body;
    const db = await dbPromise;
    const result = await db.run('UPDATE licenses SET is_active = ? WHERE license_key = ?', isActive ? 1 : 0, key);
    if (result.changes === 0) return res.status(404).json({ error: 'License not found' });
    res.json({ success: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Failed to toggle' });
  }
});

// --- 404 & Error ---
app.use((req,res)=>res.status(404).json({ error:'Not found', path:req.path }));
app.use((err,req,res,next)=>{ console.error(err.stack); res.status(500).json({ error:'Internal server error' }); });

const PORT = process.env.PORT || 3000;
app.listen(PORT,()=>console.log(`Server running on http://localhost:${PORT}`));